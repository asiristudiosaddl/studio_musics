Asiri Perera — Official Music Page (React / Vite)

How to run locally:
1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev

3. Build for production:
   npm run build

This project is ready to deploy to Vercel or Netlify. Upload the project folder (or link your repo) and the platforms will build automatically.
